"""Ming Studio helpers."""
